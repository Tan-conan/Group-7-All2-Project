import sys
from PyQt5.QtWidgets import QApplication,QDialog, QMainWindow, QTreeView, QWidget,QPushButton,QVBoxLayout,QHBoxLayout,QScrollBar
from PyQt5.QtGui import QStandardItemModel, QStandardItem, QFont
from PyQt5.QtCore import Qt
import sqlite3
from datetime import datetime

def view_history(self,user_id):
    history_dialog = HistoryDialog(self,user_id)
    history_dialog.exec_()



class HistoryDialog(QDialog):
    def __init__(self, parent,user_id):
        super().__init__(parent)

        self.setGeometry(100, 100, 1400, 300)
        self.setWindowTitle('Ticket Booking History')

        self.init_ui(user_id)

    def init_ui(self,user_id):
        # Create a tree view to display the history
        self.tree_view = QTreeView(self)
        self.tree_view.setGeometry(10, 10, 1200, 280)

        self.model = QStandardItemModel()
        self.model.setHorizontalHeaderLabels(['Attraction Name', 'Ticket Name', 'Ticket Quantity',
                                              'Ticket Date', 'Total Ticket Price','Ticket Status'])
        self.tree_view.setModel(self.model)

        # Populate the tree view with data from the database
        conn_booking = sqlite3.connect('George_database.db')
        cursor_booking = conn_booking.cursor()

        cursor_booking.execute('''
    CREATE TABLE IF NOT EXISTS Book_History (
    Booking_ID INTEGER NOT NULL,
    USER_ID INTEGER NOT NULL,
    Attraction_ID INTEGER NOT NULL,
    Ticket_ID INTEGER NOT NULL,
    Ticket_Quantity INTEGER NOT NULL,
    Ticket_Date TEXT NOT NULL,
    Total_Ticket_Price REAL NOT NULL,
    FOREIGN KEY(Ticket_ID) REFERENCES Attraction_Tickets(TICKET_ID),
    FOREIGN KEY(Attraction_ID) REFERENCES Attraction_List(Attraction_ID),
    FOREIGN KEY(USER_ID) REFERENCES Account_list(USER_ID),
    PRIMARY KEY(Booking_ID AUTOINCREMENT)
    )
    ''')

        cursor_booking.execute('SELECT bh.*, tt.Ticket_Name, at.Attraction_Name FROM Book_History bh '
                               'INNER JOIN Attraction_Tickets tt ON bh.Ticket_ID = tt.TICKET_ID '
                               'INNER JOIN Attraction_List at ON bh.Attraction_ID = at.Attraction_ID '
                               'WHERE bh.USER_ID = ?',(user_id,))
        bookings = cursor_booking.fetchall()

        for booking in bookings:
            row = [QStandardItem(str(item)) for item in booking[:6]]
            attraction_name = booking[8]
            ticket_name = booking[7]
            ticket_quantity = booking[4]
            ticket_selected_date = '2024-11-17'
            ticket_total_price = booking[6]

            # Calculate the ticket status based on the ticket_date and current date
            ticket_date = datetime.strptime(ticket_selected_date, "%Y-%m-%d").date()
            status = 'available' if datetime.now().date() <= ticket_date else 'out of date'

            row[0].setData(attraction_name, Qt.DisplayRole)
            row[1].setData(ticket_name, Qt.DisplayRole)
            row[2].setData(ticket_quantity, Qt.DisplayRole)
            row[3].setData(ticket_selected_date, Qt.DisplayRole)
            row[4].setData(ticket_total_price, Qt.DisplayRole)
            row[5].setData(status, Qt.DisplayRole)


            self.model.appendRow(row)

        conn_booking.close()

        self.tree_view.resizeColumnToContents(0)
        self.tree_view.resizeColumnToContents(1)

        scrollbar = QScrollBar(Qt.Vertical)
        scrollbar.setSingleStep(1)
        scrollbar.setMaximum(self.tree_view.verticalScrollBar().maximum())
        scrollbar.setMinimum(self.tree_view.verticalScrollBar().minimum())
        scrollbar.valueChanged.connect(self.tree_view.verticalScrollBar().setValue)

        # Create a layout for the tree view and scrollbar
        layout = QHBoxLayout(self)
        layout.addWidget(self.tree_view)
        # Create a vertical layout for the scrollbar
        v_layout = QVBoxLayout()
        v_layout.addWidget(scrollbar)

        # Add the vertical layout with the scrollbar to the main layout
        layout.addLayout(v_layout)

        self.setLayout(layout)




