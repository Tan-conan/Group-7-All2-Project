import sys
import requests
import sqlite3
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QPalette, QColor, QPixmap
from BookingPage import *

API_KEY = 'AIzaSyB6mal5jTJNZ5utjydT164kUoHpizMI6cI'

def open_add_ticket_page(self):
    self.AddTicketWindow = Add_ticket_Window()
    self.AddTicketWindow.show()
def open_attraction_detail_page(self, item, description_list,user_id):
    row = self.list_widget.row(item)
    attraction_name_text = description_list[row]

    self.detailed_attraction_window = Detail_attraction_Window(attraction_name_text,user_id)
    self.detailed_attraction_window.show()

def open_add_attraction_page(self,user_type):
    print("add attraction function executed")
    if user_type == "ADMIN":
        self.Add_Window = Add_attraction_Window()
        self.Add_Window.show()
        MainWindow.close(self)
    else:
        QMessageBox.warning(self, "Access Denied", "You do not have permission to add Attractions.")

def open_edit_attraction_page(self,user_type):
    print("edit attraction function executed")
    if user_type == "ADMIN":
        self.Edit_window = Edit_attraction_Window()
        self.Edit_window.show()
        MainWindow.close(self)
    else:
        QMessageBox.warning(self, "Access Denied", "You do not have permission to edit Attractions.")

def open_delete_attraction_page(self,user_type):
    print("delete attraction function executed")
    if user_type == "ADMIN":
        self.Delete_window = Delete_attraction_Window()
        self.Delete_window.show()
        MainWindow.close(self)
    else:
        QMessageBox.warning(self, "Access Denied", "You do not have permission to delete Attractions.")

class Add_ticket_Window(QWidget):
    def __init__(self):
        super().__init__()

        self.name_combobox = QComboBox(self)
        self.name_combobox.addItem("Select an attraction")
        self.name_combobox.setCurrentIndex(0)

        conn = sqlite3.connect('George_database.db')

        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS Attraction_Tickets (
            TICKET_ID INTEGER NOT NULL,
            ATTRACTION_ID INTEGER NOT NULL,
            Ticket_Name TEXT NOT NULL,
            Ticket_Price REAL NOT NULL,
            PRIMARY KEY(TICKET_ID AUTOINCREMENT),
            FOREIGN KEY(ATTRACTION_ID) REFERENCES Attraction_List(Attraction_ID)
            )
        ''')
        conn.commit()

        cursor.execute("SELECT Attraction_Name FROM Attraction_List")
        rows = cursor.fetchall()

        for row in rows:
            place_name = row[0]
            self.name_combobox.addItem(place_name)

        def edit_attraction():
            if self.name_combobox.currentText() == "Select an attraction":
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText("Please select an attraction name！")
                msg.setWindowTitle("error")
                msg.exec_()
            elif self.description_entry.text().strip():
                if self.URL_entry.text().strip():
                    cursor.execute("SELECT Attraction_ID FROM Attraction_List WHERE Attraction_Name = ?",(self.name_combobox.currentText(),))
                    rows = cursor.fetchall()
                    for row in rows:
                        place_id = row[0]
                    cursor.execute(
                        "INSERT INTO Attraction_Tickets (ATTRACTION_ID, Ticket_Name, Ticket_Price) VALUES "
                        "(?, ?, ?)",
                        (place_id,self.description_entry.text(),self.URL_entry.text(),))

                    print(place_id)
                    conn.commit()
                    conn.close()
                    QMessageBox.information(self, "Add ticket complete", "Add Ticket complete!")
                    Add_ticket_Window.close(self)
                else:
                    QMessageBox.warning(self, "Warning", "Please fill in prices!")
            else:
                QMessageBox.warning(self, "Warning", "Please fill in Ticket name!")

        self.setWindowTitle("Add ticket")
        self.setGeometry(200, 200, 750, 300)

        self.Add_attraction_Window_layout = QGridLayout()

        self.name_entry = QLabel("attraction name")
        self.name_entry.setFixedWidth(700)
        self.description_label = QLabel("Ticket name")
        self.description_entry = QLineEdit()
        self.description_entry.setFixedWidth(700)
        self.URL_label = QLabel("Ticket Price")
        self.URL_entry = QLineEdit()
        self.URL_entry.setFixedWidth(700)

        self.add_attraction_button = QPushButton("DONE")
        self.add_attraction_button.clicked.connect(edit_attraction)

        self.Add_attraction_Window_layout.addWidget(self.name_entry, 0, 0)
        self.Add_attraction_Window_layout.addWidget(self.name_combobox, 1, 0)
        self.Add_attraction_Window_layout.addWidget(self.description_label, 2, 0)
        self.Add_attraction_Window_layout.addWidget(self.description_entry, 3, 0)
        self.Add_attraction_Window_layout.addWidget(self.URL_label, 4, 0)
        self.Add_attraction_Window_layout.addWidget(self.URL_entry, 5, 0)
        self.Add_attraction_Window_layout.addWidget(self.add_attraction_button, 6, 0)

        self.add_attraction_window_widget = QWidget(self)
        self.add_attraction_window_widget.setLayout(self.Add_attraction_Window_layout)

        print("ok")

class Detail_attraction_Window(QWidget):
    def __init__(self, attraction_name_text,user_id):
        super().__init__()
        self.setWindowTitle(attraction_name_text)
        self.setGeometry(200, 200, 700, 400)

        # connect to database
        conn = sqlite3.connect('George_database.db')
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM Attraction_List WHERE Attraction_Name=?", (attraction_name_text,))

        # fetch data from database
        rows = cursor.fetchall()
        print(rows)
        # show error if google place api fetching process getting an error
        attraction_id = "error"
        description = "error"
        url = "error"
        type = "error"
        detailed_type = "error"

        # fetch every data from selected row
        for row in rows:
            print(attraction_name_text)
            attraction_id = row[0]
            description = row[6]
            url = row[5]
            type = row[3]
            detailed_type = row[4]

        # close database
        conn.close()

        self.Add_attraction_Window_layout = QGridLayout()

        self.name_label = QLabel("Name:")
        self.name_label2 = QLabel(attraction_name_text)
        self.type_label = QLabel("type:")
        self.type_label2 = QLabel(type)
        self.detail_type_label = QLabel("detailed_type:")
        self.detail_type_label2 = QLabel(detailed_type)
        self.description_label = QLabel("Description:")
        self.description_label2 = QLabel(description)
        # if description more than 60 words split it into next line once
        split_text = [description[i:i + 60] for i in range(0, len(description), 60)]
        formatted_text = '<br>'.join(split_text)
        self.description_label2.setText(formatted_text)
        self.URL_label = QLabel("Google Location URL")
        self.URL_label2 = QLabel(url)
        self.URL_label2.setOpenExternalLinks(True)
        # if url more than 60 words use ... to replace to rest of words
        self.URL_label2.setText(f'<a href="{url}">{url[:60]}...</a>')

        self.ticket_list = QListWidget()
        self.ticket_list.setStyleSheet("QListWidget::item { height: 50px; }")
        self.ticket_list.doubleClicked.connect(lambda:on_item_click(self))
        conn = sqlite3.connect('George_database.db')
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM Attraction_Tickets WHERE ATTRACTION_ID=?", (attraction_id,))
        ticket_data = cursor.fetchall()

        # set QListWidget minimum width
        self.ticket_list.setMinimumWidth(680)

        for row in ticket_data:
            Ticket_Name = row[2]
            Ticket_Price = row[3]
            list_ticket = QListWidgetItem(Ticket_Name + "   [RM" + str(Ticket_Price) + "]")
            list_ticket.setData(Qt.UserRole, Ticket_Name)  # 使用Qt.UserRole存储票名
            list_ticket.setData(Qt.UserRole + 1, Ticket_Price)  # 使用Qt.UserRole + 1 存储票价
            self.ticket_list.addItem(list_ticket)

        conn.close()

        self.Add_attraction_Window_layout.addWidget(self.name_label, 0, 0)
        self.Add_attraction_Window_layout.addWidget(self.name_label2, 0, 1)
        self.Add_attraction_Window_layout.addWidget(self.type_label, 2, 0)
        self.Add_attraction_Window_layout.addWidget(self.type_label2, 2, 1)
        self.Add_attraction_Window_layout.addWidget(self.detail_type_label, 3, 0)
        self.Add_attraction_Window_layout.addWidget(self.detail_type_label2, 3, 1)
        self.Add_attraction_Window_layout.addWidget(self.description_label, 4, 0, 1, 2)
        self.Add_attraction_Window_layout.addWidget(self.description_label2, 5, 0, 1, 2)
        self.Add_attraction_Window_layout.addWidget(self.URL_label, 6, 0, 1, 2)
        self.Add_attraction_Window_layout.addWidget(self.URL_label2, 7, 0, 1, 2)
        self.Add_attraction_Window_layout.addWidget(self.ticket_list, 8, 0, 1, 2)

        self.add_attraction_window_widget = QWidget(self)
        self.add_attraction_window_widget.setLayout(self.Add_attraction_Window_layout)

        def on_item_click(self):
            selected_item = self.ticket_list.currentItem()
            if selected_item:
                ticket_name = selected_item.data(Qt.UserRole)
                ticket_price = selected_item.data(Qt.UserRole + 1)
                print(f"Ticket Name: {ticket_name}, Ticket Price: {ticket_price}")
                open_Book_ticket_page(self, user_id, ticket_price, ticket_name)

class Add_attraction_Window(QWidget):
    def __init__(self):
        super().__init__()

        def add_the_attraction():
            name_to_check = self.name_entry.text()
            print(name_to_check)
            if name_to_check.strip():  # check name is empty or not
                print("QLineEdit is not empty")
                if self.description_entry.text().strip():  # check description is empty or not
                    print("description not empty")
                    if self.URL_entry.text().strip():  # check url is empty or not
                        print("url not empty")
                        if self.type_list.currentText() == "(Select a type)":  # check type is selected or not
                            QMessageBox.warning(self, "Warning", "Please select a type!")
                        else:
                            # check  detailed type is selected or not
                            if self.detailed_type_list.currentText() == "(select detailed type)":
                                QMessageBox.warning(self, "Warning", "Please select a detailed type!")
                            else:
                                # connect to database
                                conn = sqlite3.connect('George_database.db')
                                create_table = ('''
                                CREATE TABLE IF NOT EXISTS Attraction_List (
                                Attraction_ID INTEGER NOT NULL,
                                Attraction_Name TEXT NOT NULL,
                                Attraction_Rating REAL,
                                Attraction_Type TEXT NOT NULL,
                                Attraction_detailed_type TEXT NOT NULL,
                                Google_URL TEXT NOT NULL,
                                Attraction_Description TEXT NOT NULL,
                                PRIMARY KEY(Attraction_ID AUTOINCREMENT)
                                )
                                ''')
                                conn.execute(create_table)
                                cursor = conn.cursor()

                                # check for existing attraction record
                                cursor.execute("SELECT Attraction_Name FROM Attraction_List WHERE Attraction_Name=?", (name_to_check,))
                                existing_record = cursor.fetchone()

                                if existing_record:
                                    QMessageBox.warning(self, "Warning", "This attraction already exist!")
                                else:
                                    url = f'https://maps.googleapis.com/maps/api/place/textsearch/json?query={name_to_check}&key={API_KEY}'
                                    response = requests.get(url).json()
                                    print("got response")
                                    if 'results' in response:
                                        places = response['results']
                                        if places:
                                            place = places[0]
                                            name = place['name']
                                            rating = place.get('rating', '0')

                                            print(rating)
                                            insert_table = '''
                                                    INSERT INTO Attraction_List 
                                                    (Attraction_Name , Attraction_Rating , Attraction_Type , 
                                                    Attraction_detailed_type , Google_URL , Attraction_Description) 
                                                    VALUES 
                                                    (? , ? , ? , ? , ? , ?);
                                                    '''

                                            insert_tuple = (
                                                name, rating, self.type_list.currentText(),
                                                self.detailed_type_list.currentText(), self.URL_entry.text(),
                                                self.description_entry.text())
                                            print(self.name_entry.text(), self.description_entry.text(),
                                                  self.type_list.currentText())
                                            cursor.execute(insert_table, insert_tuple)
                                            conn.commit()
                                            conn.close()

                                            QMessageBox.information(self, "Add Attraction complete", "Add Attraction complete!")
                                            Add_attraction_Window.close(self)
                    else:
                        QMessageBox.warning(self, "Warning", "Please write URL!")
                else:
                    QMessageBox.warning(self, "Warning", "Please write description!")
            else:
                QMessageBox.warning(self, "Warning", "Please fill in attraction name")

        def change_detailed_type_list():
            self.detailed_type_list.clear()
            if self.type_list.currentText() == "Culture":
                self.detailed_type_list.addItems(
                    ["(select detailed type)", "Indian", "Chinese", "Malay", "thai", "christian", "others"])
            elif self.type_list.currentText() == "Food":
                self.detailed_type_list.addItems(
                    ["(select detailed type)", "Indian", "Chinese", "Malay", "thai", "others"])
            elif self.type_list.currentText() == "Accommodation":
                self.detailed_type_list.addItems(
                    ["(select detailed type)", "Hotel", "Apartment", "Motel", "resort", "others"])
            elif self.type_list.currentText() == "Nature":
                self.detailed_type_list.addItems(
                    ["(select detailed type)", "wildlife", "Forest", "Cave", "aquatic", "others"])
            elif self.type_list.currentText() == "Entertainment":
                self.detailed_type_list.addItems(
                    ["(select detailed type)", "Theater", "Museum", "Zoo", "theme park", "shopping mall", "others"])
            elif self.type_list.currentText() == "Transportation":
                self.detailed_type_list.addItems(["(select detailed type)", "Taxi", "Ferry", "Bus", "others"])
            else:
                self.detailed_type_list.addItems(["please select type above"])

        self.setWindowTitle("Add Attraction")
        self.setGeometry(200, 200, 750, 390)

        self.Add_attraction_Window_layout = QGridLayout()

        self.name_label = QLabel("Attraction name")
        self.warning_name_label = QLabel("(Warning: please avoid adding any infamous unprofessional attraction"
                                         " that is from the page that did not have any \n detail information in "
                                         "google map to prevent google place api returning error data set. )")
        self.name_entry = QLineEdit()
        self.name_entry.setFixedWidth(700)
        self.description_label = QLabel("Description")
        self.description_entry = QLineEdit()
        self.description_entry.setFixedWidth(700)
        self.URL_label = QLabel("Google Location URL")
        self.URL_entry = QLineEdit()
        self.URL_entry.setFixedWidth(700)
        self.type_list_label = QLabel("type of attraction(or transportation)")
        self.type_list = QComboBox()
        self.type_list.addItems(
            ["(Select a type)", "Culture", "Food", "Accommodation", "Nature", "Entertainment", "Transportation"])
        self.detailed_type_list_label = QLabel("detailed attraction type")
        self.detailed_type_list = QComboBox()
        self.type_list.currentTextChanged.connect(change_detailed_type_list)
        self.add_attraction_button = QPushButton("DONE")
        self.add_attraction_button.clicked.connect(add_the_attraction)
        self.add_ticket_button = QPushButton("....Or Add Ticket")
        self.add_ticket_button.clicked.connect(lambda:open_add_ticket_page(self))

        self.Add_attraction_Window_layout.addWidget(self.name_label, 0, 0)
        self.Add_attraction_Window_layout.addWidget(self.name_entry, 1, 0)
        self.Add_attraction_Window_layout.addWidget(self.warning_name_label, 2, 0)
        self.Add_attraction_Window_layout.addWidget(self.description_label, 3, 0)
        self.Add_attraction_Window_layout.addWidget(self.description_entry, 4, 0)
        self.Add_attraction_Window_layout.addWidget(self.URL_label, 5, 0)
        self.Add_attraction_Window_layout.addWidget(self.URL_entry, 6, 0)
        self.Add_attraction_Window_layout.addWidget(self.type_list_label, 7, 0)
        self.Add_attraction_Window_layout.addWidget(self.type_list, 8, 0)
        self.Add_attraction_Window_layout.addWidget(self.detailed_type_list_label, 9, 0)
        self.Add_attraction_Window_layout.addWidget(self.detailed_type_list, 10, 0)
        self.Add_attraction_Window_layout.addWidget(self.add_attraction_button, 11, 0)
        self.Add_attraction_Window_layout.addWidget(self.add_ticket_button, 12, 0)

        self.add_attraction_window_widget = QWidget(self)
        self.add_attraction_window_widget.setLayout(self.Add_attraction_Window_layout)

class Delete_attraction_Window(QWidget):
    def __init__(self):
        super().__init__()

        self.name_combobox = QComboBox(self)
        self.name_combobox.addItem("Select an attraction")
        self.name_combobox.setCurrentIndex(0)

        conn = sqlite3.connect('George_database.db')
        cursor = conn.cursor()

        cursor.execute("SELECT Attraction_Name FROM Attraction_List")
        rows = cursor.fetchall()

        # add attraction name into combobox
        for row in rows:
            place_name = row[0]
            self.name_combobox.addItem(place_name)

        def delete_attraction():
            if self.name_combobox.currentText() == "Select an attraction":
                QMessageBox.warning(self, "Access Denied", "Please choose an attraction!")
            else:
                cursor.execute("SELECT Attraction_ID FROM Attraction_List WHERE Attraction_Name = ?", (self.name_combobox.currentText(),))
                rows = cursor.fetchall()
                for row in rows:
                    attraction_id = row[0]
                cursor.execute("DELETE from Attraction_Tickets Where Attraction_ID = ?", (attraction_id,))
                conn.commit()
                cursor.execute("DELETE from Book_History Where Attraction_ID = ?", (attraction_id,))
                conn.commit()
                cursor.execute("DELETE FROM Attraction_List WHERE Attraction_Name = ?", (self.name_combobox.currentText(),))
                conn.commit()
                # close database
                conn.close()

                QMessageBox.information(self, "Delete complete", "Delete attraction successfully!")
                Delete_attraction_Window.close(self)

        self.setWindowTitle("Delete Attraction")
        self.setGeometry(200, 200, 455, 100)

        self.delete_attraction_button = QPushButton("DONE")
        self.delete_attraction_button.clicked.connect(delete_attraction)

        self.Add_attraction_Window_layout = QGridLayout()
        self.Add_attraction_Window_layout.addWidget(self.name_combobox, 0, 0)
        self.Add_attraction_Window_layout.addWidget(self.delete_attraction_button, 1, 0)

        self.add_attraction_window_widget = QWidget(self)
        self.add_attraction_window_widget.setLayout(self.Add_attraction_Window_layout)

class Edit_attraction_Window(QWidget):
    def __init__(self):
        super().__init__()

        self.name_combobox = QComboBox(self)
        self.name_combobox.addItem("Select an attraction")
        self.name_combobox.setCurrentIndex(0)

        conn = sqlite3.connect('George_database.db')

        cursor = conn.cursor()

        cursor.execute("SELECT Attraction_Name FROM Attraction_List")
        rows = cursor.fetchall()

        for row in rows:
            place_name = row[0]
            self.name_combobox.addItem(place_name)

        def input_informations():
            cursor.execute("SELECT * FROM Attraction_List WHERE Attraction_Name = ?", (self.name_combobox.currentText(),))
            rows = cursor.fetchall()
            for row in rows:
                url = row[5]
                self.URL_entry.setText(url)
                description = row[6]
                self.description_entry.setText(description)
                type = row[3]
                self.type_list.setCurrentText(type)
                change_detailed_type_list()
                detailed_type = row[4]
                self.detailed_type_list.setCurrentText(detailed_type)

        self.name_combobox.currentTextChanged.connect(input_informations)

        def edit_attraction():
            if self.name_combobox.currentText() == "Select an attraction":
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText("Please select an attraction name！")
                msg.setWindowTitle("error")
                msg.exec_()
            elif self.description_entry.text().strip():
                if self.URL_entry.text().strip():
                    if self.detailed_type_list.currentText() == "(select detailed type)":
                        QMessageBox.warning(self, "Error", "Please select a detailed type!")
                    else:
                        cursor.execute(
                            "UPDATE Attraction_List SET Attraction_Type = ? ,Attraction_detailed_type = ?, "
                            "Google_URL = ? , Attraction_Description = ? WHERE Attraction_Name = ?",
                            (self.type_list.currentText(), self.detailed_type_list.currentText(), self.URL_entry.text(),
                             self.description_entry.text(),
                             self.name_combobox.currentText(),))

                        print(self.name_combobox.currentText())
                        conn.commit()
                        conn.close()
                        QMessageBox.information(self, "Edit complete", "Edit attraction complete!")
                        Edit_attraction_Window.close(self)
                else:
                    msg2 = QMessageBox()
                    msg2.setIcon(QMessageBox.Warning)
                    msg2.setText("Please fill in url")
                    msg2.setWindowTitle("error")
                    msg2.exec_()
            else:
                msg1 = QMessageBox()
                msg1.setIcon(QMessageBox.Warning)
                msg1.setText("Please fill in description！")
                msg1.setWindowTitle("error")
                msg1.exec_()

        self.setWindowTitle("Edit Attraction")
        self.setGeometry(200, 200, 750, 300)

        self.Add_attraction_Window_layout = QGridLayout()

        self.name_entry = QLabel("attraction name")
        self.name_entry.setFixedWidth(700)
        self.description_label = QLabel("Description")
        self.description_entry = QLineEdit()
        self.description_entry.setFixedWidth(700)
        self.URL_label = QLabel("Google Location URL")
        self.URL_entry = QLineEdit()
        self.URL_entry.setFixedWidth(700)
        self.type_list_label = QLabel("type of attraction(or transportation)")
        self.type_list = QComboBox()
        self.type_list.addItems(["Culture", "Food", "Accommodation", "Nature", "Entertainment", "Transportation"])
        self.detailed_type_list = QComboBox()

        def text_changed(s):  # s is a str
            print(s)

        def change_detailed_type_list():
            self.detailed_type_list.clear()
            if self.type_list.currentText() == "Culture":
                self.detailed_type_list.addItems(
                    ["(select detailed type)", "Indian", "Chinese", "Malay", "thai", "christian", "others"])
            elif self.type_list.currentText() == "Food":
                self.detailed_type_list.addItems(
                    ["(select detailed type)", "Indian", "Chinese", "Malay", "thai", "others"])
            elif self.type_list.currentText() == "Accommodation":
                self.detailed_type_list.addItems(
                    ["(select detailed type)", "Hotel", "Apartment", "Motel", "resort", "others"])
            elif self.type_list.currentText() == "Nature":
                self.detailed_type_list.addItems(
                    ["(select detailed type)", "wildlife", "Forest", "Cave", "aquatic", "others"])
            elif self.type_list.currentText() == "Entertainment":
                self.detailed_type_list.addItems(
                    ["(select detailed type)", "Theater", "Museum", "Zoo", "theme park", "shopping mall", "others"])
            elif self.type_list.currentText() == "Transportation":
                self.detailed_type_list.addItems(["(select detailed type)", "Taxi", "Ferry", "Bus", "others"])
            else:
                self.detailed_type_list.addItems(["please select type above"])

        self.type_list.currentTextChanged.connect(change_detailed_type_list)

        self.type_list.currentTextChanged.connect(text_changed)
        self.add_attraction_button = QPushButton("DONE")
        self.add_attraction_button.clicked.connect(edit_attraction)

        self.Add_attraction_Window_layout.addWidget(self.name_entry, 0, 0)
        self.Add_attraction_Window_layout.addWidget(self.name_combobox, 1, 0)
        self.Add_attraction_Window_layout.addWidget(self.description_label, 2, 0)
        self.Add_attraction_Window_layout.addWidget(self.description_entry, 3, 0)
        self.Add_attraction_Window_layout.addWidget(self.URL_label, 4, 0)
        self.Add_attraction_Window_layout.addWidget(self.URL_entry, 5, 0)
        self.Add_attraction_Window_layout.addWidget(self.type_list_label, 6, 0)
        self.Add_attraction_Window_layout.addWidget(self.type_list, 7, 0)
        self.Add_attraction_Window_layout.addWidget(self.detailed_type_list, 8, 0)
        self.Add_attraction_Window_layout.addWidget(self.add_attraction_button, 9, 0)

        self.add_attraction_window_widget = QWidget(self)
        self.add_attraction_window_widget.setLayout(self.Add_attraction_Window_layout)

        print("ok")

class MainWindow(QMainWindow):
    def __init__(self,title,user_type,user_id):
        print(user_id)
        super(MainWindow, self).__init__()

        self.setWindowTitle(title)
        self.setGeometry(100, 100, 1200, 600)

        self.Main_layout = QVBoxLayout()
        self.culture_layout = QGridLayout()

        self.go_back_button = QPushButton("BACK")
        self.go_back_button.clicked.connect(self.hide)
        self.go_back_button.setFixedWidth(50)
        self.go_back_button.setFixedHeight(40)

        self.go_back_button.setStyleSheet("QPushButton {"
                                          "font-family: Bahnschrift SemiLight SemiConde; "
                                          "background-color: #FFA703;"
                                          "font-size: 16px;"
                                          "color: white;}"
                                          "QPushButton:hover { background-color: #ffc14d;"
                                          "font-weight: bold;}")

        self.Attraction_Filter = QComboBox(self)
        # add types into combobox according to page type
        if self.windowTitle() == "Culture":
            self.Attraction_Filter.addItems(["Show All Type", "Indian", "Chinese", "Malay", "thai", "christian", "others"])
        elif self.windowTitle() == "Food":
            self.Attraction_Filter.addItems(["Show All Type", "Indian", "Chinese", "Malay", "thai", "others"])
        elif self.windowTitle() == "Accommodation":
            self.Attraction_Filter.addItems(["Show All Type", "Hotel", "Apartment", "Motel", "resort", "others"])
        elif self.windowTitle() == "Nature":
            self.Attraction_Filter.addItems(["Show All Type", "wildlife", "Forest", "Cave", "aquatic", "others"])
        elif self.windowTitle() == "Entertainment":
            self.Attraction_Filter.addItems(
                ["Show All Type", "Theater", "Museum", "Zoo", "theme park", "shopping mall", "others"])
        elif self.windowTitle() == "Transportation":
            self.Attraction_Filter.addItems(["Show All Type", "Taxi", "Ferry", "Bus", "others"])
        else:
            print("ha")

        self.Attraction_Filter.setFixedWidth(150)
        self.Attraction_Filter.setFixedHeight(40)
        self.Attraction_Filter.setStyleSheet("font-family:Bahnschrift SemiLight SemiConde; "
                                             "selection-background-color: #ffc14d;"
                                             "background-color: #FFA703;"
                                             "font-size: 16px; "
                                             "color: white;")

        self.sort_combobox = QComboBox(self)
        self.sort_combobox.setFixedWidth(150)
        self.sort_combobox.setFixedHeight(40)
        self.sort_combobox.addItems(
            ["Sort By Default", "Sort By A-Z", "Sort By Z-A", "Sort By Ratings ASC", "Sort By Ratings DESC"])
        self.sort_combobox.setStyleSheet("font-family:Bahnschrift SemiLight SemiConde; "
                                         "selection-background-color: #ffc14d;"
                                         "background-color: #FFA703;"
                                         "font-size: 16px; "
                                         "color: white;")

        self.admin_add_attraction_button = QPushButton("ADD")
        self.admin_add_attraction_button.setFixedWidth(80)
        self.admin_add_attraction_button.setFixedHeight(40)
        self.admin_add_attraction_button.clicked.connect(lambda: open_add_attraction_page(self,user_type))
        self.admin_add_attraction_button.setStyleSheet("QPushButton {"
                                                       "font-family: Bahnschrift SemiLight SemiConde; "
                                                       "background-color: #FFA703;"
                                                       "font-size: 16px;"
                                                       "color: white;}"
                                                       "QPushButton:hover { background-color: #ffc14d;"
                                                       "font-weight: bold;}")

        self.admin_delete_button = QPushButton("DELETE")
        self.admin_delete_button.setFixedWidth(80)
        self.admin_delete_button.setFixedHeight(40)
        self.admin_delete_button.clicked.connect(lambda: open_delete_attraction_page(self,user_type))
        self.admin_delete_button.setStyleSheet("QPushButton {"
                                                       "font-family: Bahnschrift SemiLight SemiConde; "
                                                       "background-color: #FFA703;"
                                                       "font-size: 16px;"
                                                       "color: white;}"
                                                       "QPushButton:hover { background-color: #ffc14d;"
                                                       "font-weight: bold;}")

        self.admin_edit_button = QPushButton("EDIT")
        self.admin_edit_button.setFixedWidth(80)
        self.admin_edit_button.setFixedHeight(40)
        self.admin_edit_button.clicked.connect(lambda: open_edit_attraction_page(self,user_type))
        self.admin_edit_button.setStyleSheet("QPushButton {"
                                             "font-family: Bahnschrift SemiLight SemiConde; "
                                             "background-color: #FFA703;"
                                             "font-size: 16px;"
                                             "color: white;}"
                                             "QPushButton:hover { background-color: #ffc14d;"
                                             "font-weight: bold;}")

        self.culture_layout.addWidget(self.go_back_button, 0, 0, 0, 4)
        self.culture_layout.addWidget(self.Attraction_Filter, 0, 3)
        self.culture_layout.addWidget(self.sort_combobox, 0, 4)
        self.culture_layout.addWidget(self.admin_add_attraction_button, 0, 5)
        self.culture_layout.addWidget(self.admin_delete_button, 0, 6)
        self.culture_layout.addWidget(self.admin_edit_button, 0, 7)

        widget = QWidget()
        widget.setLayout(self.culture_layout)
        self.Main_layout.addWidget(widget, 1)  # Widget with a stretch factor of 1

        self.scroll_area = QScrollArea()
        self.list_widget = QListWidget()

        self.description_list = []

        def input_items():
            self.description_list.clear()

            conn = sqlite3.connect('George_database.db')
            create_table = ('''
            CREATE TABLE IF NOT EXISTS Attraction_List (
            Attraction_ID INTEGER NOT NULL,
            Attraction_Name TEXT NOT NULL,
            Attraction_Rating REAL,
            Attraction_Type TEXT NOT NULL,
            Attraction_detailed_type TEXT NOT NULL,
            Google_URL TEXT NOT NULL,
            Attraction_Description TEXT NOT NULL,
            PRIMARY KEY(Attraction_ID AUTOINCREMENT)
            )
            ''')
            conn.execute(create_table)
            cursor = conn.cursor()
            conn.commit()

            if self.sort_combobox.currentText() == "Sort By Default":
                if self.Attraction_Filter.currentText() == "Show All Type":
                    cursor.execute("SELECT * FROM Attraction_List WHERE Attraction_Type=?", (title,))
                else:
                    cursor.execute("SELECT * FROM Attraction_List WHERE Attraction_Type=? and Attraction_detailed_type=?",
                                   (title, self.Attraction_Filter.currentText(),))
            else:
                if self.sort_combobox.currentText() == "Sort By A-Z":
                    if self.Attraction_Filter.currentText() == "Show All Type":
                        cursor.execute("SELECT * FROM Attraction_List WHERE Attraction_Type=? ORDER BY Attraction_Name", (title,))
                    else:
                        cursor.execute("SELECT * FROM Attraction_List WHERE Attraction_Type=? and "
                                       "Attraction_detailed_type=? ORDER BY Attraction_Name",
                                       (title, self.Attraction_Filter.currentText(),))
                    print("sort by A-Z")
                elif self.sort_combobox.currentText() == "Sort By Z-A":
                    if self.Attraction_Filter.currentText() == "Show All Type":
                        cursor.execute("SELECT * FROM Attraction_List WHERE Attraction_Type=? ORDER BY Attraction_Name DESC", (title,))
                    else:
                        cursor.execute(
                            "SELECT * FROM Attraction_List WHERE Attraction_Type=? and "
                            "Attraction_detailed_type=? ORDER BY Attraction_Name DESC",
                            (title, self.Attraction_Filter.currentText(),))
                    print("sort by Z-A")
                elif self.sort_combobox.currentText() == "Sort By Ratings ASC":
                    if self.Attraction_Filter.currentText() == "Show All Type":
                        cursor.execute("SELECT * FROM Attraction_List WHERE Attraction_Type=? ORDER BY Attraction_Rating;", (title,))
                    else:
                        cursor.execute(
                            "SELECT * FROM Attraction_List WHERE Attraction_Type=? and Attraction_detailed_type=? "
                            "ORDER BY Attraction_Rating;",
                            (title, self.Attraction_Filter.currentText(),))
                    print("sort by rating ASC")
                elif self.sort_combobox.currentText() == "Sort By Ratings DESC":
                    if self.Attraction_Filter.currentText() == "Show All Type":
                        cursor.execute("SELECT * FROM Attraction_List WHERE Attraction_Type=? ORDER BY Attraction_Rating DESC;",
                                       (title,))
                    else:
                        cursor.execute(
                            "SELECT * FROM Attraction_List WHERE Attraction_Type=? and "
                            "Attraction_detailed_type=? ORDER BY Attraction_Rating DESC;",
                            (title, self.Attraction_Filter.currentText(),))
                    print("sort by rating ASC")

            rows = cursor.fetchall()

            for row in rows:
                search_name = row[1]
                detailed_type = row[4]
                url = f'https://maps.googleapis.com/maps/api/place/textsearch/json?query={search_name}&key={API_KEY}'
                response = requests.get(url).json()

                if 'results' in response:
                    places = response['results']
                    if places:
                        place = places[0]
                        name = place['name']
                        rating = place.get('rating', '0')

                        place_id = place['place_id']
                        url = f"https://maps.googleapis.com/maps/api/place/details/json?placeid={place_id}&fields=photo&key={API_KEY}"
                        response = requests.get(url)
                        data = response.json()

                        if 'photos' in data['result']:
                            photo_reference = data['result']['photos'][0]['photo_reference']
                            image_url = f"https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference={photo_reference}&key={API_KEY}"
                            image_response = requests.get(image_url)

                            if image_response.status_code == 200:
                                image_data = image_response.content

                                item = QListWidgetItem()
                                item_widget = QWidget()
                                self.description_label = QLabel(f"{name}")
                                self.description_label.setStyleSheet("font-family:Bahnschrift SemiLight SemiConde; "
                                                                     "font-size: 20px; "
                                                                     "color: black;")
                                self.description_label2 = QLabel(f"{rating}")
                                self.description_label2.setStyleSheet("font-family:Bahnschrift SemiLight SemiConde; "
                                                                     "font-size: 20px; "
                                                                     "color: black;")
                                self.description_label3 = QLabel("Name:")
                                self.description_label3.setStyleSheet("font-family:Bahnschrift SemiLight SemiConde; "
                                                                     "font-size: 20px; "
                                                                     "color: black;")
                                self.description_label4 = QLabel("Rating:")
                                self.description_label4.setStyleSheet("font-family:Bahnschrift SemiLight SemiConde; "
                                                                     "font-size: 20px; "
                                                                     "color: black;")
                                self.description_label5 = QLabel("Type:")
                                self.description_label5.setStyleSheet("font-family:Bahnschrift SemiLight SemiConde; "
                                                                     "font-size: 20px; "
                                                                     "color: black;")
                                self.description_label6 = QLabel(detailed_type)
                                self.description_label6.setStyleSheet("font-family:Bahnschrift SemiLight SemiConde; "
                                                                     "font-size: 20px; "
                                                                     "color: black;")
                                self.blank_label = QLabel("")
                                image_label = QLabel()

                                pixmap = QPixmap()
                                pixmap.loadFromData(image_data)

                                # scale picture to a fixed size
                                scaled_pixmap = pixmap.scaled(300, 200)

                                image_label.setPixmap(scaled_pixmap)

                                self.item_layout = QGridLayout()
                                self.item_layout.addWidget(self.description_label, 0, 3)
                                self.item_layout.addWidget(self.description_label2, 1, 3)
                                self.item_layout.addWidget(self.description_label3, 0, 2)
                                self.item_layout.addWidget(self.description_label4, 1, 2)
                                self.item_layout.addWidget(self.description_label5, 2, 2)
                                self.item_layout.addWidget(self.description_label6, 2, 3)
                                self.item_layout.addWidget(self.blank_label, 3, 0, 2, 1)
                                self.item_layout.addWidget(image_label, 0, 0, 5, 0)
                                item_widget.setLayout(self.item_layout)
                                item.setSizeHint(item_widget.sizeHint())
                                self.list_widget.addItem(item)
                                self.list_widget.setItemWidget(item, item_widget)

                                self.description_list.append(name)

                                name_to_check = search_name

                                # check to existing record
                                cursor.execute("SELECT Attraction_Name FROM Attraction_List WHERE Attraction_Name=?", (name_to_check,))
                                existing_record = cursor.fetchone()

                                if existing_record:
                                    print(f"This place '{name_to_check}' is exist。")
                                else:
                                    insert_table = '''
                                                    INSERT INTO Attraction_List 
                                                    (Attraction_Name , Attraction_Rating) 
                                                    VALUES 
                                                    (? , ?);
                                                    '''

                                    insert_tuple = (self.description_label.text(), self.description_label2.text())
                                    cursor.execute(insert_table, insert_tuple)

                                    conn.commit()

        def ReloadContent():
            for i in reversed(range(self.list_widget.count())):
                item = self.list_widget.takeItem(i)
                if item is not None:
                    widget = self.list_widget.itemWidget(item)
                    if widget is not None:
                        widget.deleteLater()

            input_items()

        self.Attraction_Filter.currentTextChanged.connect(ReloadContent)
        self.sort_combobox.currentTextChanged.connect(ReloadContent)

        input_items()

        self.list_widget.itemDoubleClicked.connect(
            lambda item: open_attraction_detail_page(self, item, self.description_list,user_id))

        self.scroll_area.setWidget(self.list_widget)
        self.scroll_area.setWidgetResizable(True)
        self.Main_layout.addWidget(self.scroll_area, 10)

        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        central_widget.setLayout(self.Main_layout)


