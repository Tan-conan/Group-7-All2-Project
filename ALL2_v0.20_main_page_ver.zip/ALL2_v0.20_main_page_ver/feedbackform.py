import sys
from PyQt5.QtWidgets import *
from email.message import EmailMessage
import smtplib
import ssl

class FeedbackForm(QWidget):
    def __init__(self):
        super().__init__()  # Add parentheses here

        self.setWindowTitle("George Guide Feedback Form")
        self.setGeometry(100, 100, 450, 400)

        layout = QVBoxLayout(self)

        name_label = QLabel("Name:")
        self.name_input = QLineEdit()

        email_label = QLabel("Email:")
        self.email_input = QLineEdit()

        rating_label = QLabel("How satisfied are you with the George's Guide?")
        self.rating_layout = QHBoxLayout()
        self.rating_buttons = []
        for i in range(1, 6):
            button = QRadioButton(str(i))
            self.rating_buttons.append(button)
            self.rating_layout.addWidget(button)

        title_label = QLabel("Title:")
        self.title_input = QLineEdit()

        feedback_label = QLabel("Feedback:")
        self.feedback_text = QTextEdit()

        submit_button = QPushButton("Submit")
        submit_button.setFixedWidth(100)

        # Center the submit button by adding horizontal spacer items
        spacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        button_layout = QHBoxLayout()
        button_layout.addItem(spacer)
        button_layout.addWidget(submit_button)
        button_layout.addItem(spacer)

        layout.addWidget(name_label)
        layout.addWidget(self.name_input)
        layout.addWidget(email_label)
        layout.addWidget(self.email_input)
        layout.addWidget(rating_label)
        layout.addLayout(self.rating_layout)
        layout.addWidget(title_label)
        layout.addWidget(self.title_input)
        layout.addWidget(feedback_label)
        layout.addWidget(self.feedback_text)
        layout.addLayout(button_layout)

        submit_button.clicked.connect(self.submit_feedback)

    def clear_form(self):
        # Clear all input fields
        self.name_input.clear()
        self.email_input.clear()
        self.title_input.clear()
        self.feedback_text.clear()
        for button in self.rating_buttons:
            button.setChecked(False)

    def submit_feedback(self):
        name = self.name_input.text()
        email = self.email_input.text()
        title = self.title_input.text()
        feedback = self.feedback_text.toPlainText()

        selected_rating = None
        for button in self.rating_buttons:
            if button.isChecked():
                selected_rating = button.text()
                break

        email_sender = 'kiosktourism@gmail.com'
        email_password = 'upqs hhwq iyzt wipp'
        email_receiver = 'kiosktourism@gmail.com'

        em = EmailMessage()
        em['To'] = email_receiver
        email_content = f"Name: {name}\nEmail: {title}\nRating: {email}\nTitle: {selected_rating}\nFeedback: {feedback}"

        em.set_content(email_content)
        context = ssl.create_default_context()

        if selected_rating is not None:
            with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
                smtp.login(email_sender, email_password)
                smtp.send_message(em)
            self.clear_form()
            QMessageBox.information(self, "Feedback Sent", "Thank you for your feedback. Your feedback has been sent.")
        else:
            print("Please select a rating.")
