from PyQt5 import QtCore, QtGui, QtWidgets
import sys
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, QtWidgets
import sqlite3
from SearchPage import *
from book_history import *
import subprocess
import webbrowser

class Ui_MainPage(QWidget):
    def link_to_feedback_form(self):
        from feedbackform import FeedbackForm
        self.feedbackwindow =FeedbackForm()
        self.feedbackwindow.show()

    def open_open_chat_bot(self):
        # url of chatbot page
        url = 'https://tawk.to/chat/6541d45af2439e1631ea899a/1he4ib14g'
        # Open the URL in the default web browser
        webbrowser.open(url)
    def open_window_a(self,title,user_type,user_id):
        from Attraction_page import MainWindow
        self.window_a = MainWindow(title,user_type,user_id)
        self.window_a.show()

    def open_quiz_window(self):
        subprocess.run(['python', 'quizPage.py'])


    def __init__(self, main_window,user_type,user_id):
        super().__init__()
        self.main_window = main_window

        main_window.setWindowTitle(user_type + "'s Main Page")
        self.setFixedWidth(800)
        self.setFixedHeight(500)
        self.CulturepushButton = QtWidgets.QPushButton(self)
        self.CulturepushButton.setGeometry(QtCore.QRect(30, 80, 231, 151))
        self.CulturepushButton.clicked.connect(lambda:self.open_window_a("Culture",user_type,user_id))
        font = QtGui.QFont()
        font.setFamily("Impact")
        font.setPointSize(30)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.CulturepushButton.setFont(font)
        self.CulturepushButton.setStyleSheet(
            "QPushButton{ background-image: url(picture/Culture_pic.png); }\n"
            "QPushButton {color: white;}\n"
            "")
        self.CulturepushButton.setObjectName("CulturepushButton")
        self.FoodpushButton = QtWidgets.QPushButton(self)
        self.FoodpushButton.setGeometry(QtCore.QRect(280, 80, 231, 151))
        self.FoodpushButton.clicked.connect(lambda: self.open_window_a("Food",user_type,user_id))
        font = QtGui.QFont()
        font.setFamily("Impact")
        font.setPointSize(33)
        font.setBold(True)
        font.setWeight(75)
        self.FoodpushButton.setFont(font)
        self.FoodpushButton.setStyleSheet(
            "QPushButton{ background-image: url(picture/Food_Pic.png); }\n"
            "QPushButton {color: white;}\n"
            "")
        self.FoodpushButton.setObjectName("FoodpushButton")
        self.AccommodationpushButton = QtWidgets.QPushButton(self)
        self.AccommodationpushButton.setGeometry(QtCore.QRect(530, 80, 241, 151))
        self.AccommodationpushButton.clicked.connect(lambda: self.open_window_a("Accommodation",user_type,user_id))
        font = QtGui.QFont()
        font.setFamily("Impact")
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.AccommodationpushButton.setFont(font)
        self.AccommodationpushButton.setStyleSheet(
            "QPushButton{ background-image: url(picture/Accommodation_Pic.png); }\n"
            "QPushButton {color: white;}")
        self.AccommodationpushButton.setObjectName("AccommodationpushButton")
        self.NaturepushButton = QtWidgets.QPushButton(self)
        self.NaturepushButton.setGeometry(QtCore.QRect(30, 250, 231, 151))
        self.NaturepushButton.clicked.connect(lambda: self.open_window_a("Nature",user_type,user_id))
        font = QtGui.QFont()
        font.setFamily("Impact")
        font.setPointSize(29)
        font.setBold(True)
        font.setWeight(75)
        self.NaturepushButton.setFont(font)
        self.NaturepushButton.setStyleSheet(
            "QPushButton{ background-image: url(picture/Nature_Pic.png); }\n"
            "QPushButton {color: white;}\n"
            "")
        self.NaturepushButton.setObjectName("NaturepushButton")
        self.EntertainmentpushButton = QtWidgets.QPushButton(self)
        self.EntertainmentpushButton.setGeometry(QtCore.QRect(280, 250, 231, 151))
        self.EntertainmentpushButton.clicked.connect(lambda: self.open_window_a("Entertainment",user_type,user_id))
        font = QtGui.QFont()
        font.setFamily("Impact")
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.EntertainmentpushButton.setFont(font)
        self.EntertainmentpushButton.setStyleSheet(
            "QPushButton{ background-image: url(picture/Entertainment_Page.png); }\n"
            "QPushButton {color: white;}\n"
            "")
        self.EntertainmentpushButton.setObjectName("EntertainmentpushButton")
        self.TransportationpushButton = QtWidgets.QPushButton(self)
        self.TransportationpushButton.setGeometry(QtCore.QRect(530, 250, 241, 151))
        self.TransportationpushButton.clicked.connect(lambda: self.open_window_a("Transportation",user_type,user_id))
        font = QtGui.QFont()
        font.setFamily("Impact")
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.TransportationpushButton.setFont(font)
        self.TransportationpushButton.setStyleSheet(
            "QPushButton{ background-image: url(picture/Transportation_Pic.png); }\n"
            "QPushButton {color: white;}\n"
            "")
        self.TransportationpushButton.setObjectName("TransportationpushButton")
        self.Search_pushButton = QtWidgets.QPushButton(self)
        self.Search_pushButton.setGeometry(QtCore.QRect(30, 10, 121, 50))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift SemiBold SemiConden")
        font.setPointSize(12)
        self.Search_pushButton.setStyleSheet("QPushButton {"
                                             "font-family: Bahnschrift SemiLight SemiConde; "
                                             "background-color: #FFA703;"
                                             "font-size: 16px;"
                                             "color: white;}"
                                             "QPushButton:hover { background-color: #ffc14d;"
                                             "font-weight: bold;}")
        self.Search_pushButton.setFont(font)
        self.Search_pushButton.setObjectName("Search_pushButton")
        self.Search_pushButton.clicked.connect(lambda:open_Search_page(self,user_type,user_id))

        self.History_pushButton = QtWidgets.QPushButton(self)
        self.History_pushButton.setGeometry(QtCore.QRect(160, 10, 121, 50))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift SemiBold SemiConden")
        font.setPointSize(12)
        self.History_pushButton.setStyleSheet("QPushButton {"
                                             "font-family: Bahnschrift SemiLight SemiConde; "
                                             "background-color: #FFA703;"
                                             "font-size: 16px;"
                                             "color: white;}"
                                             "QPushButton:hover { background-color: #ffc14d;"
                                             "font-weight: bold;}")
        self.History_pushButton.setFont(font)
        self.History_pushButton.setObjectName("Search_pushButton")
        self.History_pushButton.clicked.connect(lambda:view_history(self,user_id))

        self.Feedback_pushButton = QtWidgets.QPushButton(self)
        self.Feedback_pushButton.setGeometry(QtCore.QRect(652, 10, 121, 50))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift SemiBold SemiConden")
        font.setPointSize(9)
        self.Feedback_pushButton.setStyleSheet("QPushButton {"
                                               "font-family: Bahnschrift SemiLight SemiConde; "
                                               "background-color: #FFA703;"
                                               "font-size: 16px;"
                                               "color: white;}"
                                               "QPushButton:hover { background-color: #ffc14d;"
                                               "font-weight: bold;}")
        self.Feedback_pushButton.setFont(font)
        self.Feedback_pushButton.setObjectName("Feedback_pushButton")
        self.Feedback_pushButton.clicked.connect(lambda:self.link_to_feedback_form())
        self.pushButton = QtWidgets.QPushButton(self)
        self.pushButton.setGeometry(QtCore.QRect(700, 420, 71, 71))
        self.pushButton.setStyleSheet(
            "QPushButton{ background-image: url(picture/chat_icon.png); }")
        self.pushButton.setText("")
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(lambda:self.open_open_chat_bot())
        self.quizpushButton = QtWidgets.QPushButton(self)
        self.quizpushButton.setGeometry(QtCore.QRect(30, 420, 71, 71))
        self.quizpushButton.setStyleSheet(
            "QPushButton{ background-image: url(picture/quiz_icon.png); }\n"
            "QPushButton {color: white;}")
        self.quizpushButton.setText("")
        self.quizpushButton.setObjectName("quizpushButton")
        self.quizpushButton.clicked.connect(lambda: self.open_quiz_window())

        self.retranslateUi()
        QtCore.QMetaObject.connectSlotsByName(self)
        Ui_MainPage.show(self)

    def retranslateUi(self):
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("MainPage", "George\'s Guide Main Page"))
        self.CulturepushButton.setText(_translate("MainPage", "Culture"))
        self.FoodpushButton.setText(_translate("MainPage", "Food"))
        self.AccommodationpushButton.setText(_translate("MainPage", "Accommodation"))
        self.NaturepushButton.setText(_translate("MainPage", "Nature"))
        self.EntertainmentpushButton.setText(_translate("MainPage", "Entertainment"))
        self.TransportationpushButton.setText(_translate("MainPage", "Transportation"))
        self.Search_pushButton.setText(_translate("MainPage", "Search Page"))
        self.History_pushButton.setText(_translate("MainPage", "Ticket History"))
        self.Feedback_pushButton.setText(_translate("MainPage", "Contact us"))