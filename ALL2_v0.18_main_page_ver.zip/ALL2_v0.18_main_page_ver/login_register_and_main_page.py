import sys
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, QtWidgets
import sqlite3
from ForgotPasswordPage import *
from George_Main_Page import *

def open_sub_window(self,user_type,user_id):
    # create main page
    main_window = QMainWindow()

    ui = Ui_MainPage(main_window,user_type,user_id)

    main_window.setCentralWidget(ui)

    # show main page
    main_window.show()
    MainWindow.hide(self)

class Register_page(QWidget):
    def __init__(self,main_window):
        super().__init__()
        self.main_window = main_window

        self.setObjectName("Register_Page")
        self.resize(921, 581)
        self.Register_picture = QtWidgets.QLabel(self)
        self.Register_picture.setGeometry(QtCore.QRect(0, 0, 921, 581))
        self.Register_picture.setText("")
        self.Register_picture.setPixmap(QtGui.QPixmap(
            "picture/ALL2_Login_register_Image.png"))
        self.Register_picture.setScaledContents(True)
        self.Register_picture.setObjectName("Register_picture")
        self.Register_frame = QtWidgets.QFrame(self)
        self.Register_frame.setGeometry(QtCore.QRect(290, 60, 351, 451))
        font = QtGui.QFont()
        font.setFamily("Arial")
        self.Register_frame.setFont(font)
        self.Register_frame.setAutoFillBackground(True)
        self.Register_frame.setStyleSheet("background-color: #FFFFF;")
        self.Register_frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.Register_frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.Register_frame.setObjectName("Register_frame")
        self.Register_label = QtWidgets.QLabel(self.Register_frame)
        self.Register_label.setEnabled(True)
        self.Register_label.setGeometry(QtCore.QRect(70, 20, 201, 51))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.Register_label.sizePolicy().hasHeightForWidth())
        self.Register_label.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setFamily("Segoe Script")
        font.setPointSize(26)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        font.setKerning(True)
        self.Register_label.setFont(font)
        self.Register_label.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.Register_label.setAutoFillBackground(False)
        self.Register_label.setAlignment(QtCore.Qt.AlignCenter)
        self.Register_label.setObjectName("Register_label")
        self.Email_line = QtWidgets.QLineEdit(self.Register_frame)
        self.Email_line.setGeometry(QtCore.QRect(50, 170, 251, 31))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift Light")
        self.Email_line.setFont(font)
        self.Email_line.setObjectName("Email_line")
        self.Password_line = QtWidgets.QLineEdit(self.Register_frame)
        self.Password_line.setGeometry(QtCore.QRect(50, 220, 251, 31))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift Light")
        self.Password_line.setFont(font)
        self.Password_line.setInputMask("")
        self.Password_line.setText("")
        self.Password_line.setClearButtonEnabled(False)
        self.Password_line.setObjectName("Password_line")
        self.Password_line.setEchoMode(QLineEdit.Password)
        self.Register_Picture2 = QtWidgets.QLabel(self.Register_frame)
        self.Register_Picture2.setGeometry(QtCore.QRect(0, 80, 351, 20))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift Light")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.Register_Picture2.setFont(font)
        self.Register_Picture2.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.Register_Picture2.setAlignment(QtCore.Qt.AlignCenter)
        self.Register_Picture2.setObjectName("Register_Picture2")
        self.RegisterpushButton = QtWidgets.QPushButton(self.Register_frame)
        self.RegisterpushButton.setGeometry(QtCore.QRect(50, 340, 251, 41))
        self.RegisterpushButton.clicked.connect(lambda: register_user(self))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift SemiLight SemiConde")
        font.setPointSize(12)
        self.RegisterpushButton.setFont(font)
        self.RegisterpushButton.setAutoFillBackground(False)
        self.RegisterpushButton.setStyleSheet("background-color: #FFA703;\n"
                                           "color: #FFFFFF;\n"
                                           "")
        self.RegisterpushButton.setAutoDefault(False)
        self.RegisterpushButton.setObjectName("LoginpushButton")
        self.Username_line = QtWidgets.QLineEdit(self.Register_frame)
        self.Username_line.setGeometry(QtCore.QRect(50, 120, 251, 31))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift Light")
        self.Username_line.setFont(font)
        self.Username_line.setObjectName("Email_line_2")
        self.Password_line_2 = QtWidgets.QLineEdit(self.Register_frame)
        self.Password_line_2.setGeometry(QtCore.QRect(50, 270, 251, 31))
        self.Password_line_2.setEchoMode(QLineEdit.Password)
        font = QtGui.QFont()
        font.setFamily("Bahnschrift Light")
        self.Password_line_2.setFont(font)
        self.Password_line_2.setInputMask("")
        self.Password_line_2.setText("")
        self.Password_line_2.setClearButtonEnabled(False)
        self.Password_line_2.setObjectName("Password_line_2")
        self.checkBox = QtWidgets.QCheckBox(self.Register_frame)
        self.checkBox.setGeometry(QtCore.QRect(180, 310, 121, 20))
        self.checkBox.stateChanged.connect(self.toggleShowPassword)
        font = QtGui.QFont()
        font.setFamily("Bahnschrift Light")
        self.checkBox.setFont(font)
        self.checkBox.setObjectName("checkBox")
        self.BacktoLoginpushButton = QtWidgets.QPushButton(self.Register_frame)
        self.BacktoLoginpushButton.setGeometry(QtCore.QRect(120, 390, 111, 28))
        self.BacktoLoginpushButton.clicked.connect(lambda: toggleMainWindow(self))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift SemiLight SemiConde")
        font.setPointSize(9)
        self.BacktoLoginpushButton.setFont(font)
        self.BacktoLoginpushButton.setStyleSheet("border: none; background: none;;")
        self.BacktoLoginpushButton.setObjectName("BacktoLoginpushButton")

        self.retranslateUi()
        QtCore.QMetaObject.connectSlotsByName(self)

        def register_user(self):
            username = self.Username_line.text()
            email = self.Email_line.text()
            password = self.Password_line.text()
            print(username)
            print(email)
            print(password)

            if username.strip():
                if email.strip():
                    keyword = "@"
                    keyword2 = ".com"
                    if keyword in email:
                        if keyword2 in email:
                            if password.strip():
                                if password == self.Password_line_2.text():
                                    # database
                                    conn = sqlite3.connect('George_database.db')
                                    create_table = '''
                                                           CREATE TABLE IF NOT EXISTS Account_list
                                                           (USER_ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, username TEXT , 
                                                           account_type TEXT , password TEXT , email TEXT )
                                                           '''
                                    conn.execute(create_table)
                                    cursor = conn.cursor()
                                    cursor.execute('''SELECT * FROM Account_list WHERE username=? OR email=?''',
                                                   (username, email,))
                                    check_user_input = cursor.fetchone()
                                    if check_user_input is not None:
                                        QMessageBox.warning(window, "ERROR", "This username or email already used!")
                                    else:
                                        insert_table = '''
                                                               INSERT INTO Account_list 
                                                               (username , account_type , password , email) 
                                                               VALUES 
                                                               (? , ? , ? , ?);
                                                               '''

                                        insert_tuple = (username, "USER", password, email)
                                        cursor.execute(insert_table, insert_tuple)
                                        QMessageBox.information(window, "REGISTER COMPLETE",
                                                                "Register complete,thank you!")
                                        toggleMainWindow(self)

                                        conn.commit()
                                        conn.close()
                                else:
                                    QMessageBox.warning(window, "ERROR", "Two password are not the same!")
                            else:
                                QMessageBox.warning(window, "ERROR", "Please fill in password!")
                        else:
                            QMessageBox.warning(window, "ERROR", "Not a valid email!")
                    else:
                        QMessageBox.warning(window, "ERROR", "Not a valid email!")
                else:
                    QMessageBox.warning(window, "ERROR", "Please fill in email!")
            else:
                QMessageBox.warning(window, "ERROR", "Please fill in username!")

        def toggleMainWindow(self):
            self.main_window.show()
            self.hide()

    def toggleShowPassword(self, state):
        if state == 2:
            self.Password_line_2.setEchoMode(QLineEdit.Normal)
            self.Password_line.setEchoMode(QLineEdit.Normal)
        else:
            self.Password_line_2.setEchoMode(QLineEdit.Password)
            self.Password_line.setEchoMode(QLineEdit.Password)


    def retranslateUi(self):
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("Register_Page", "Register with George\'s Guide"))
        self.Register_label.setText(_translate("Register_Page", "Register"))
        self.Email_line.setPlaceholderText(_translate("Register_Page", "  Email"))
        self.Password_line.setPlaceholderText(_translate("Register_Page", "  New Password"))
        self.Register_Picture2.setText(_translate("Register_Page", " discover the beautiful Penang with us"))
        self.RegisterpushButton.setText(_translate("Register_Page", "Register"))
        self.Username_line.setPlaceholderText(_translate("Register_Page", "  Username"))
        self.Password_line_2.setPlaceholderText(_translate("Register_Page", "  Comfirm Password"))
        self.checkBox.setText(_translate("Register_Page", "Show Password"))
        self.BacktoLoginpushButton.setText(_translate("Register_Page", "Back to Login Page"))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("My App")

        self.setObjectName("LoginPage")
        self.resize(908, 575)
        self.centralwidget = QtWidgets.QWidget(self)
        self.centralwidget.setObjectName("centralwidget")
        self.Login_picture = QtWidgets.QLabel(self.centralwidget)
        self.Login_picture.setGeometry(QtCore.QRect(-6, -5, 921, 581))
        self.Login_picture.setAutoFillBackground(True)
        self.Login_picture.setText("")
        self.Login_picture.setPixmap(QtGui.QPixmap(
            "picture\ALL2_Login_register_Image.png"))
        self.Login_picture.setScaledContents(True)
        self.Login_picture.setObjectName("Login_picture")
        self.Login_frame = QtWidgets.QFrame(self.centralwidget)
        self.Login_frame.setGeometry(QtCore.QRect(290, 90, 351, 401))
        font = QtGui.QFont()
        font.setFamily("Arial")
        self.Login_frame.setFont(font)
        self.Login_frame.setAutoFillBackground(True)
        self.Login_frame.setStyleSheet("background-color: #FFFFF;")
        self.Login_frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.Login_frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.Login_frame.setObjectName("Login_frame")
        self.Welcome_label = QtWidgets.QLabel(self.Login_frame)
        self.Welcome_label.setEnabled(True)
        self.Welcome_label.setGeometry(QtCore.QRect(70, 20, 201, 51))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.Welcome_label.sizePolicy().hasHeightForWidth())
        self.Welcome_label.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setFamily("Segoe Script")
        font.setPointSize(26)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        font.setKerning(True)
        self.Welcome_label.setFont(font)
        self.Welcome_label.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.Welcome_label.setAutoFillBackground(False)
        self.Welcome_label.setAlignment(QtCore.Qt.AlignCenter)
        self.Welcome_label.setObjectName("Welcome_label")
        self.Email_line = QtWidgets.QLineEdit(self.Login_frame)
        self.Email_line.setGeometry(QtCore.QRect(50, 120, 251, 31))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift Light")
        self.Email_line.setFont(font)
        self.Email_line.setObjectName("Email_line")
        self.Password_line = QtWidgets.QLineEdit(self.Login_frame)
        self.Password_line.setGeometry(QtCore.QRect(50, 170, 251, 31))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift Light")
        self.Password_line.setFont(font)
        self.Password_line.setInputMask("")
        self.Password_line.setText("")
        self.Password_line.setClearButtonEnabled(False)
        self.Password_line.setObjectName("Password_line")
        self.Welcome_label2 = QtWidgets.QLabel(self.Login_frame)
        self.Welcome_label2.setGeometry(QtCore.QRect(80, 70, 181, 20))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift Light")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.Welcome_label2.setFont(font)
        self.Welcome_label2.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.Welcome_label2.setAlignment(QtCore.Qt.AlignCenter)
        self.Welcome_label2.setObjectName("Welcome_label2")
        self.LoginpushButton = QtWidgets.QPushButton(self.Login_frame)
        self.LoginpushButton.setGeometry(QtCore.QRect(50, 250, 251, 41))
        self.LoginpushButton.clicked.connect(lambda: login(self))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift SemiLight SemiConde")
        font.setPointSize(12)
        self.LoginpushButton.setStyleSheet("QPushButton {background-color: #FFA703;"
                                           "color: white;}"
                                           "QPushButton:hover { background-color: #ffc14d;}")
        self.LoginpushButton.setFont(font)
        self.LoginpushButton.setAutoFillBackground(False)
        self.LoginpushButton.setAutoDefault(False)
        self.LoginpushButton.setObjectName("LoginpushButton")
        self.new_here_label = QtWidgets.QLabel(self.Login_frame)
        self.new_here_label.setGeometry(QtCore.QRect(30, 310, 231, 21))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift SemiLight SemiConde")
        font.setPointSize(9)
        self.new_here_label.setFont(font)
        self.new_here_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignTrailing | QtCore.Qt.AlignVCenter)
        self.new_here_label.setIndent(-1)
        self.new_here_label.setOpenExternalLinks(False)
        self.new_here_label.setObjectName("new_here_label")
        self.RegisterpushButton = QtWidgets.QPushButton(self.Login_frame)
        self.RegisterpushButton.setGeometry(QtCore.QRect(260, 310, 61, 21))
        self.RegisterpushButton.clicked.connect(lambda:toggleSecondaryWindow(self))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift SemiLight SemiConde")
        font.setPointSize(9)
        font.setBold(True)
        font.setWeight(75)
        self.RegisterpushButton.setFont(font)
        self.RegisterpushButton.setStyleSheet("border: none; background: none;;")
        self.RegisterpushButton.setObjectName("RegisterpushButton")
        self.ForgotPasswordpushButton = QtWidgets.QPushButton(self.Login_frame)
        self.ForgotPasswordpushButton.setGeometry(QtCore.QRect(180, 210, 131, 31))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift SemiLight SemiConde")
        font.setPointSize(9)
        font.setBold(False)
        font.setWeight(50)
        self.ForgotPasswordpushButton.setFont(font)
        self.ForgotPasswordpushButton.setStyleSheet("border: none; background: none;;")
        self.ForgotPasswordpushButton.setObjectName("ForgotPasswordpushButton")
        self.ForgotPasswordpushButton.clicked.connect(lambda:open_RetrivePassword_page(self))
        self.setCentralWidget(self.centralwidget)

        self.retranslateUi(self)
        QtCore.QMetaObject.connectSlotsByName(self)

        self.secondary_window = None

        def toggleSecondaryWindow(self):
            if self.secondary_window is None:
                self.secondary_window = Register_page(self)
            self.secondary_window.show()
            self.hide()

        def login(self):
            email = self.Email_line.text()
            password = self.Password_line.text()
            print(email)
            print(password)

            if email.strip():
                if password.strip():
                    # database
                    conn = sqlite3.connect('George_database.db')
                    create_table = '''
                            CREATE TABLE IF NOT EXISTS Account_list
                            (USER_ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, username TEXT , 
                            account_type TEXT , password TEXT , email TEXT )
                            '''
                    conn.execute(create_table)
                    cursor = conn.cursor()
                    cursor.execute('SELECT COUNT(*) FROM Account_list WHERE email=?', (email,))
                    row_count = cursor.fetchone()[0]

                    if row_count > 0:
                        cursor.execute('''SELECT * FROM Account_list WHERE email=?''',
                                       (email,))
                        rows = cursor.fetchall()
                        for row in rows:
                            check_user_password = row[3]
                            user_type = row[2]
                            username = row[1]
                            user_id = row[0]
                        print(check_user_password+"\n")
                        print(user_type + "\n")
                        print(username + "\n")
                        if check_user_password != password:
                            QMessageBox.warning(window, "ERROR", "Wrong password for this email!")
                        else:
                            QMessageBox.information(window, "LOGIN COMPLETE",
                                                    "Login complete! \n welcome, " + user_type + " " + username)
                            open_sub_window(self, user_type, user_id)

                        conn.commit()
                        conn.close()
                    else:
                        QMessageBox.warning(window, "ERROR", "This email is not exist!")
                else:
                    QMessageBox.warning(window, "ERROR", "Please fill in password!")
            else:
                QMessageBox.warning(window, "ERROR", "Please fill in email!")

    def retranslateUi(self, LoginPage):
        _translate = QtCore.QCoreApplication.translate
        LoginPage.setWindowTitle(_translate("LoginPage", "Welcome to George\'s Guide"))
        self.Welcome_label.setText(_translate("LoginPage", "Welcome"))
        self.Email_line.setPlaceholderText(_translate("LoginPage", "  Email"))
        self.Password_line.setPlaceholderText(_translate("LoginPage", "  Password"))
        self.Welcome_label2.setText(_translate("LoginPage", "to George\'s guide"))
        self.LoginpushButton.setText(_translate("LoginPage", "Login"))
        self.new_here_label.setText(_translate("LoginPage", "New here? You\'re always welcome for "))
        self.RegisterpushButton.setText(_translate("LoginPage", "Register"))
        self.ForgotPasswordpushButton.setText(_translate("LoginPage", "Forgot Password?"))

app = QApplication(sys.argv)

window = MainWindow()
window.show()
app.exec()
