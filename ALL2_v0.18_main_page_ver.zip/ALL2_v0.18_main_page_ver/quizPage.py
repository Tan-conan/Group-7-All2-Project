import tkinter as tk
from tkinter import messagebox, ttk
from ttkbootstrap import Style

# Define the quiz data directly in the code
quiz_data = [
    {
        "question": "Who is Fort Cornwallis named after?",
        "choices": ["Sir Stamford Raffles", "Captain Francis Light", "Charles Cornwallis", "Queen Victoria"],
        "answer": "Charles Cornwallis"
    },
    {
        "question": "Which country originally constructed Fort Cornwallis?",
        "choices": ["Portugal", " Netherlands", "Spain", "Great Britain"],
        "answer": "Great Britain"
    },
    {
        "question": "What is the shape of Fort Cornwallis?",
        "choices": ["Star", "Triangle", "Square", "Circle"],
        "answer": "Star"
    },
    {
        "question": "In which century was Fort Cornwallis built?",
        "choices": ["16th century", "17th century", "18th century", "19th century"],
        "answer": "18th century"
    }

]


# Function to display the current question and choices
def show_question():
    # Get the current question from the quiz_data list
    question = quiz_data[current_question]
    qs_label.config(text=question["question"])

    # Display the choices on the buttons
    choices = question["choices"]
    for i in range(4):
        choice_btns[i].config(text=choices[i], state="normal")  # Reset button state

    # Clear the feedback label and disable the next button
    feedback_label.config(text="")
    next_btn.config(state="disabled")


# Function to check the selected answer and provide feedback
def check_answer(choice):
    # Get the current question from the quiz_data list
    question = quiz_data[current_question]
    selected_choice = choice_btns[choice].cget("text")

    # Check if the selected choice matches the correct answer
    if selected_choice == question["answer"]:
        # Update the score and display it
        global score
        score += 1
        score_label.config(text="Score: {}/{}".format(score, len(quiz_data)))
        feedback_label.config(text="Correct!", foreground="green")
    else:
        # Display the correct answer when the user selects the wrong choice
        correct_answer = question["answer"]
        feedback_label.config(text="Incorrect! Correct answer: {}".format(correct_answer), foreground="red")

    # Disable all choice buttons and enable the next button
    for button in choice_btns:
        button.config(state="disabled")
    next_btn.config(state="normal")


# Function to move to the next question
def next_question():
    global current_question
    current_question += 1

    if current_question < len(quiz_data):
        # If there are more questions, show the next question
        show_question()
    else:
        # If all questions have been answered, display the final score and end the quiz
        messagebox.showinfo("Quiz Completed",
                            "Quiz Completed! Final score: {}/{}".format(score, len(quiz_data)))
        root.destroy()


# Create the main window
root = tk.Tk()
root.title("Quiz App")
root.geometry("700x900")
style = Style(theme="flatly")

# Load an image
image_path = r'picture\quiz_photo.png'  # Replace with the actual path to your image
image = tk.PhotoImage(file=image_path)

# Create the Fort Cornwallis label
fort_label = ttk.Label(
    root,
    text="Fort Cornwallis",
    anchor="center",
    font=("Bahnschrift semilight semiconde", 24),
    padding=10
)
fort_label.pack(pady=10)

# Create the image label
image_label = tk.Label(root, image=image)
image_label.pack()

# Configure the font size for the question and choice buttons
style.configure("TLabel", font=("Bahnschrift semilight semiconde", 20))
style.configure("TButton", font=("Bahnschrift semilight semiconde", 16))

# Create the question label
qs_label = ttk.Label(
    root,
    anchor="center",
    wraplength=1000,
    padding=10
)
qs_label.pack(pady=10)

# Create the choice buttons
choice_btns = []
for i in range(4):
    button = ttk.Button(
        root,
        command=lambda i=i: check_answer(i)
    )
    button.pack(pady=5)
    choice_btns.append(button)

# Create the feedback label
feedback_label = ttk.Label(
    root,
    anchor="center",
    padding=10
)
feedback_label.pack(pady=2)

# Initialize the score
score = 0

# Create the score label
score_label = ttk.Label(
    root,
    text="Score: 0/{}".format(len(quiz_data)),
    anchor="center",
    padding=10
)
score_label.pack(pady=2)

# Create the next button
next_btn = ttk.Button(
    root,
    text="Next",
    command=next_question,
    state="disabled"
)
next_btn.pack(pady=2)

# Initialize the current question index
current_question = 0

# Show the first question
show_question()

# Start the main event loop
root.mainloop()
