import sys
import requests
import sqlite3
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QPalette, QColor, QPixmap
from fuzzywuzzy import fuzz
from Attraction_page import *

API_KEY = 'AIzaSyB6mal5jTJNZ5utjydT164kUoHpizMI6cI'
def open_Search_page(self,user_type,user_id):
    self.AddTicketWindow = Search_Window(user_type,user_id)
    print(user_type)
    self.AddTicketWindow.show()

class Search_Window(QWidget):
    def __init__(self,user_type,user_id):
        super().__init__()

        self.setWindowTitle("Search Page")
        self.setGeometry(200, 200, 1200, 600)

        self.Main_layout = QVBoxLayout()
        self.culture_layout = QGridLayout()

        self.go_back_button = QPushButton("BACK")
        self.go_back_button.clicked.connect(self.hide)
        self.go_back_button.setFixedWidth(50)
        self.go_back_button.setFixedHeight(40)

        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("search for it")
        self.search_box.setFixedWidth(300)
        self.search_box.setFixedHeight(40)

        self.search_button = QPushButton("SEARCH")
        self.search_button.setFixedWidth(70)
        self.search_button.setFixedHeight(40)

        self.culture_layout.addWidget(self.go_back_button, 0, 0)
        self.culture_layout.addWidget(self.search_box, 0, 1)
        self.culture_layout.addWidget(self.search_button, 0, 2)

        widget = QWidget()
        widget.setLayout(self.culture_layout)
        self.Main_layout.addWidget(widget, 1)  # Widget with a stretch factor of 1

        self.scroll_area = QScrollArea()
        self.list_widget = QListWidget()

        self.description_list = []

        def input_items():
            self.description_list.clear()

            conn = sqlite3.connect('George_database.db')
            create_table = ('''CREATE TABLE IF NOT EXISTS attraction_list (
                                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                                        name TEXT NOT NULL,
                                        rating INT,
                                        type TEXT,
                                        detailed_type TEXT,
                                        google_url TEXT,
                                        description TEXT
                                        )''')
            conn.execute(create_table)
            cursor = conn.cursor()
            conn.commit()

            cursor.execute("SELECT * FROM attraction_list")

            rows = cursor.fetchall()

            for row in rows:
                search_name = row[1]
                detailed_type = row[4]
                if self.search_box.text().strip():
                    similarity_ratio = fuzz.ratio(self.search_box.text(), search_name)
                    print(self.search_box.text())
                    print(search_name)
                    if similarity_ratio >= 35:
                        print("proceed")
                    else:
                        continue
                else:
                    print("pass")

                url = f'https://maps.googleapis.com/maps/api/place/textsearch/json?query={search_name}&key={API_KEY}'
                response = requests.get(url).json()

                if 'results' in response:
                    places = response['results']
                    if places:
                        place = places[0]
                        name = place['name']
                        rating = place.get('rating', '0')

                        place_id = place['place_id']
                        url = f"https://maps.googleapis.com/maps/api/place/details/json?placeid={place_id}&fields=photo&key={API_KEY}"
                        response = requests.get(url)
                        data = response.json()

                        if 'photos' in data['result']:
                            photo_reference = data['result']['photos'][0]['photo_reference']
                            image_url = f"https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference={photo_reference}&key={API_KEY}"
                            image_response = requests.get(image_url)

                            if image_response.status_code == 200:
                                image_data = image_response.content

                                item = QListWidgetItem()
                                item_widget = QWidget()
                                self.description_label = QLabel(f"{name}")
                                self.description_label2 = QLabel(f"{rating}")
                                self.description_label3 = QLabel("Name:")
                                self.description_label4 = QLabel("Rating:")
                                self.description_label5 = QLabel("Type:")
                                self.description_label6 = QLabel(detailed_type)
                                image_label = QLabel()

                                pixmap = QPixmap()
                                pixmap.loadFromData(image_data)

                                # scale picture to a fixed size
                                scaled_pixmap = pixmap.scaled(300, 200)

                                image_label.setPixmap(scaled_pixmap)

                                self.item_layout = QGridLayout()
                                self.item_layout.addWidget(self.description_label, 0, 3)
                                self.item_layout.addWidget(self.description_label2, 1, 3)
                                self.item_layout.addWidget(self.description_label3, 0, 2)
                                self.item_layout.addWidget(self.description_label4, 1, 2)
                                self.item_layout.addWidget(self.description_label5, 2, 2)
                                self.item_layout.addWidget(self.description_label6, 2, 3)
                                self.item_layout.addWidget(image_label, 0, 0, 3, 0)
                                item_widget.setLayout(self.item_layout)
                                item.setSizeHint(item_widget.sizeHint())
                                self.list_widget.addItem(item)
                                self.list_widget.setItemWidget(item, item_widget)

                                self.description_list.append(name)

                                name_to_check = search_name

                                # check to existing record
                                cursor.execute("SELECT name FROM attraction_list WHERE name=?", (name_to_check,))
                                existing_record = cursor.fetchone()

                                if existing_record:
                                    print(f"attraction '{name_to_check}' already exist。")
                                else:
                                    insert_table = '''
                                                                            INSERT INTO attraction_list 
                                                                            (name , rating) 
                                                                            VALUES 
                                                                            (? , ?);
                                                                            '''

                                    insert_tuple = (self.description_label.text(), self.description_label2.text())
                                    cursor.execute(insert_table, insert_tuple)

                                    conn.commit()

        def ReloadContent():
            for i in reversed(range(self.list_widget.count())):
                item = self.list_widget.takeItem(i)
                if item is not None:
                    widget = self.list_widget.itemWidget(item)
                    if widget is not None:
                        widget.deleteLater()

            input_items()

        self.search_button.clicked.connect(lambda:ReloadContent())

        input_items()

        self.list_widget.itemDoubleClicked.connect(
            lambda item: open_attraction_detail_page(self, item, self.description_list,user_id))

        self.scroll_area.setWidget(self.list_widget)
        self.scroll_area.setWidgetResizable(True)
        self.Main_layout.addWidget(self.scroll_area, 10)

        self.setLayout(self.Main_layout)
