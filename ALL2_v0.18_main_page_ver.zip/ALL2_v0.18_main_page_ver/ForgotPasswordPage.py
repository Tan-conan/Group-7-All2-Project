import sys
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, QtWidgets
import sqlite3
import smtplib
from email.message import EmailMessage
import getpass

def open_RetrivePassword_page(self):
    self.TakePassWindow = Ui_ForgotPassword_Page()
    self.TakePassWindow.show()

password_window = None

class Ui_ForgotPassword_Page(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("ForgotPassword_Page")
        self.resize(921, 581)
        self.ForgotPassword_picture = QtWidgets.QLabel(self)
        self.ForgotPassword_picture.setGeometry(QtCore.QRect(0, 0, 921, 581))
        self.ForgotPassword_picture.setText("")
        self.ForgotPassword_picture.setPixmap(QtGui.QPixmap("picture/ALL2_Login_register_Image.png"))
        self.ForgotPassword_picture.setScaledContents(True)
        self.ForgotPassword_picture.setObjectName("ForgotPassword_picture")
        self.retrievepassword_frame = QtWidgets.QFrame(self)
        self.retrievepassword_frame.setGeometry(QtCore.QRect(220, 130, 491, 341))
        font = QtGui.QFont()
        font.setFamily("Arial")
        self.retrievepassword_frame.setFont(font)
        self.retrievepassword_frame.setAutoFillBackground(True)
        self.retrievepassword_frame.setStyleSheet("background-color: #FFFFF;")
        self.retrievepassword_frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.retrievepassword_frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.retrievepassword_frame.setObjectName("retrievepassword_frame")
        self.ForgotPassword_label = QtWidgets.QLabel(self.retrievepassword_frame)
        self.ForgotPassword_label.setEnabled(True)
        self.ForgotPassword_label.setGeometry(QtCore.QRect(20, 40, 451, 51))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.ForgotPassword_label.sizePolicy().hasHeightForWidth())
        self.ForgotPassword_label.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setFamily("Segoe Script")
        font.setPointSize(26)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        font.setStrikeOut(False)
        font.setKerning(True)
        self.ForgotPassword_label.setFont(font)
        self.ForgotPassword_label.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.ForgotPassword_label.setAutoFillBackground(False)
        self.ForgotPassword_label.setAlignment(QtCore.Qt.AlignCenter)
        self.ForgotPassword_label.setObjectName("ForgotPassword_label")
        self.Email_line = QtWidgets.QLineEdit(self.retrievepassword_frame)
        self.Email_line.setGeometry(QtCore.QRect(120, 150, 251, 31))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift Light")
        self.Email_line.setFont(font)
        self.Email_line.setObjectName("Email_line")
        self.ForgotPassword_Picture2 = QtWidgets.QLabel(self.retrievepassword_frame)
        self.ForgotPassword_Picture2.setGeometry(QtCore.QRect(40, 110, 400, 20))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift Light")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.ForgotPassword_Picture2.setFont(font)
        self.ForgotPassword_Picture2.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.ForgotPassword_Picture2.setAlignment(QtCore.Qt.AlignCenter)
        self.ForgotPassword_Picture2.setObjectName("ForgotPassword_Picture2")
        self.LoginpushButton = QtWidgets.QPushButton(self.retrievepassword_frame)
        self.LoginpushButton.setGeometry(QtCore.QRect(150, 200, 181, 41))
        self.LoginpushButton.clicked.connect(lambda: retrieve_password(self))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift SemiLight SemiConde")
        font.setPointSize(12)
        self.LoginpushButton.setFont(font)
        self.LoginpushButton.setAutoFillBackground(False)
        self.LoginpushButton.setStyleSheet("background-color: #FFA703;\n"
"color: #FFFFFF;\n"
"")
        self.LoginpushButton.setAutoDefault(False)
        self.LoginpushButton.setObjectName("LoginpushButton")
        self.BacktoLoginpushButton = QtWidgets.QPushButton(self.retrievepassword_frame)
        self.BacktoLoginpushButton.setGeometry(QtCore.QRect(180, 280, 111, 28))
        font = QtGui.QFont()
        font.setFamily("Bahnschrift SemiLight SemiConde")
        font.setPointSize(9)
        self.BacktoLoginpushButton.setFont(font)
        self.BacktoLoginpushButton.setStyleSheet("border: none; background: none;;")
        self.BacktoLoginpushButton.setObjectName("BacktoLoginpushButton")
        self.BacktoLoginpushButton.clicked.connect(lambda:Go_back_to_login(self))

        self.retranslateUi()
        QtCore.QMetaObject.connectSlotsByName(self)

        def Go_back_to_login(self):
            self.hide()

        def retrieve_password(self):
            email = self.Email_line.text()

            try:
                # Connect to the SQLite database
                conn = sqlite3.connect('George_database.db')
                cursor = conn.cursor()

                # Retrieve the password for the provided email
                cursor.execute("SELECT password FROM Account_list WHERE email = ?", (email,))
                result = cursor.fetchone()

                if result:
                    password = result[0]

                    # Send the password to the provided email
                    email_sender = 'kiosktourism@gmail.com'
                    email_password = 'upqs hhwq iyzt wipp'
                    email_receiver = email

                    em = EmailMessage()
                    em['To'] = email_receiver
                    em['Subject'] = 'Password Retrieval For Tourism Kiosk '
                    em.set_content(f"Your login password for George's Guide is:'{password}'")

                    context = smtplib.SMTP_SSL('smtp.gmail.com', 465)

                    # Login to your email account
                    context.login(email_sender, email_password)

                    # Send the email
                    context.send_message(em)

                    self.show_message_dialog("Password Retrieval", f"Password sent to {email}, may be filtered as spam")
                else:
                    self.show_message_dialog("Password Retrieval", "Email not found in the database.")
            except Exception as e:
                self.show_message_dialog("Password Retrieval", "An error occurred. Please try again later.")
                print(f"Database error: {e}")

    def show_message_dialog(self, title, message):
            from PyQt5.QtWidgets import QMessageBox
            msg = QMessageBox()
            msg.setWindowTitle(title)
            msg.setText(message)
            msg.exec_()

    def retranslateUi(self):
            _translate = QtCore.QCoreApplication.translate
            self.setWindowTitle(_translate("ForgotPassword_Page", "Register with George\'s Guide"))
            self.ForgotPassword_label.setText(_translate("ForgotPassword_Page", "Forgot Password?"))
            self.Email_line.setPlaceholderText(_translate("ForgotPassword_Page", "  Email"))
            self.ForgotPassword_Picture2.setText(
                _translate("ForgotPassword_Page", "Enter your email to retrieve your forgotten password"))
            self.LoginpushButton.setText(_translate("ForgotPassword_Page", "Send "))
            self.BacktoLoginpushButton.setText(_translate("ForgotPassword_Page", "Back to Login Page"))
